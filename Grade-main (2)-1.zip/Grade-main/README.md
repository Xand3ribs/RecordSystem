# Grade
Letter grade written in C
